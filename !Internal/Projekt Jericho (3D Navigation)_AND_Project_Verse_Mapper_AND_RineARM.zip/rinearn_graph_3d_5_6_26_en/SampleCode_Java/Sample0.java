import com.rinearn.graph3d.RinearnGraph3D;

public class Sample0 {

	public static void main(String[] args) {
		
		// Launches the graph
		RinearnGraph3D graph = new RinearnGraph3D();
	}
}